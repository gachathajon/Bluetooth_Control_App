package com.waithira.bluetoothc

import junit.framework.TestCase

class MainActivityTest : TestCase()