package com.waithira.bluetoothc

import android.bluetooth.BluetoothAdapter
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
//bluetooth adapter

lateinit var bAdapter:BluetoothAdapter

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //init bluetooth adapter
        bAdapter = BluetoothAdapter.getDefaultAdapter()
        //check if bluetooth is on/off
        if (bAdapter==null){
           bluetoothStatusTv.text = "Bluetooth is not available"
        }

    }
}